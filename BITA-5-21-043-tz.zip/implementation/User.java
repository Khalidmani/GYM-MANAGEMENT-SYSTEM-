public class User implements Serializable{
    
    private Long id;
    private String name;
    private String date;
    private String password;
    private String email;
    private String responsible;
    private int occupation;
    private int permissions;
    
    
    public User() {
    }

    public User(Long id, String name, String date, String password, String email, String responsible, int occupation, int permissions) {
        this.setId(id);
        this.setName(name);
        this.setDate(date);
        this.setPassword(password);
        this.setEmail(email);
        this.setResponsible(responsible);
        this.setOccupation(occupation);
        this.setPermissions(permissions);
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if(!name.isEmpty()){
            this.name = name;
        }
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        if(!date.isEmpty()){
            this.date = date;
        }
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        if(!password.isEmpty()){
            this.password = password;
        }
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        if(!email.isEmpty()){
            this.email = email;
        }
    }

    public String getResponsible() {
        return responsible;
    }

    public void setResponsible(String responsable) {
        if(!responsable.isEmpty()){
            this.responsible = responsable;
        }
    }

    public int getOccupation() {
        return occupation;
    }

    public void setOccupation(int Occupation) {
        if(Occupation > -1 && Occupation < 3 ){
            this.occupation = Occupation;
        }
    }

    public int getPermissions() {
        return permissions;
    }

    public void setPermissions(int permissions) {
        if(permissions > -1 && permissions < 2 ){
            this.permissions = permissions;
        }else{
            this.permissions = 1;
        }
    }
}