import java.util.Scanner;
public class Customer extends User{
    private long id;


    public Customer(  Long id, String name,String date,String password,String email, String responsible, int occupation, int permissions,String long id){
        super(name,address,phoneno,email);
        this.long id=long id;
    }
    public Customer( long id){
        this.long id="001";
    }
    

    public void setid( long id){
        this.long id=long id;
    }

    public String getid(){
        return long id;
    }
   
    public String toString(){
       return  " YOR NAME IS"+ super.getName()+ "ARRESS" +super.getOccupation() + " responsible " + super.getResponsible() +  " EMAIL" + super.getEmail() +"AND YOUR ID IS"
       +long id;
    }
}