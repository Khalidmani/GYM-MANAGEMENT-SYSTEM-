public class Payment extends Mypayments {
	
	public void init()throws Exception	{
		
		
	}
	public void service(ServletRequest request,
			ServletResponse response) throws ServletException, IOException
	{
		PrintWriter pw = response.getWriter();  
		String n=request.getParameter("pay_no");  
		String p=request.getParameter("amt");  
		String e=request.getParameter("cid");  
		
		
		int PAY_NO=Integer.parseInt(n);
		int AMOUNT=Integer.parseInt(p);
		int CID=Integer.parseInt(e);

PreparedStatement ps=con.prepareStatement("insert into PAYMENT values(?,?,?)");  

		ps.setInt(1,PAY_NO);  
		ps.setInt(2,AMOUNT);  
		ps.setInt(3,CID);  
		 
		int i=ps.executeUpdate();  
		if(i>0) 
		{	
		pw.print("You are successfully registered...");  
		}
		else
		{	
		pw.print("You are Not successfully registered...");
		}
		  
		}catch(Exception e2) {System.out.println(e2);}  
			
			pw.close();
			}
}