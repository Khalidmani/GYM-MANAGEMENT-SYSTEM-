public class Fitness{
    private int fitness_id;
    private   String type;
    private  String details;

    public Fitness(){
    }

    public Fitness(int fitness_id,String type String type,String details){
        this.fitness_id=fitness_id;
        this.type= type;
        this.details=details;
    }

    public String gettype(){
        return type;
    }

    public void settype(String type){
        this.type=type;
    }
     public String getdetails(){
        return details;
    }

    public void setdetails(String details){
        this.details=details;
    }

    public void se Fitness(int fitness_id){
        this.fitness_id=fitness_id;

    }
    public int ge Fitness(){
        return fitness_id;
    }

}