public class Customer extends Mypayments {

	public void int()throws Exception{
		try{
			Class.forName();  
		}catch(Exception e)
		{
			System.out.print(e);
		}
		
		
	}
	public void service(ServletRequest request,
			ServletResponse response) throws ServletException, IOException
	{ 
		String CNAME=request.getParameter("cname");  
		String p=request.getParameter("cid");  
		String PAYMENT_OPYION=request.getParameter("payop");  
		String ss=request.getParameter("ph");  
		String pu=request.getParameter("tid");
		String dg=request.getParameter("sid");
		
		int CID=Integer.parseInt(p);
		int PHONE=Integer.parseInt(ss);
		int MID=Integer.parseInt(pu);
		int SID=Integer.parseInt(dg);
try{  
		ps.setString(1,CNAME);  
		ps.setInt(2,CID);  
		ps.setString(3,PAYMENT_OPYION);  
		ps.setInt(4,PHONE);  
		ps.setInt(5,MID);  
		ps.setInt(6,SID);  
		int i=ps.executeUpdate();  
		if(i>0) 
		{	
		pw.print("You are successfully registered...");  
		}
		else
		{	
		pw.print("You are Not successfully registered...");
		}
		  
		}catch(Exception e2) {System.out.println(e2);}  
			
			pw.close();
			}
}